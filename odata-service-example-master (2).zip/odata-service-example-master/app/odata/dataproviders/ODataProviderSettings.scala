package odata.dataproviders

case class ODataProviderSettings(connectionString: String, username: String, password: String, providerType: String)
